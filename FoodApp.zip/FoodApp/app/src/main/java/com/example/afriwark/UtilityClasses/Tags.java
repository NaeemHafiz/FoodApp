package com.example.afriwark.UtilityClasses;

public class Tags {
    public static final String APP_PREFS = "foodapp_prefs";
    public static final String USER_EMAIL = "email";
    public static final String USER_ID = "USER_ID";

}
