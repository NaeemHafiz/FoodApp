package com.example.afriwark.Interface;

import android.view.View;

import com.example.afriwark.Models.SearchClasses.Datum;

public interface ClickListener {
    void onItemClick(Datum data);
}
